#include "inital.h"

inital::inital(void)
{
}

inital::~inital(void)
{
}
