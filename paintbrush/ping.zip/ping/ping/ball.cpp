#include "ball.h"

ball::ball(void)
{
}

ball::~ball(void)
{
}
